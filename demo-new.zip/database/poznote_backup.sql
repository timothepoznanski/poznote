-- Poznote Database Dump
-- Generated on 2026-01-24 00:54:19

DROP TABLE IF EXISTS "entries";
CREATE TABLE entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trash INTEGER DEFAULT 0,
        heading TEXT,
        entry TEXT,
        created DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated DATETIME,
        tags TEXT,
        folder TEXT DEFAULT "Default",
        workspace TEXT DEFAULT "Poznote",
        favorite INTEGER DEFAULT 0,
        attachments TEXT,
        type TEXT DEFAULT "note"
    , location TEXT, subheading TEXT, folder_id INTEGER REFERENCES folders(id) ON DELETE SET NULL);

INSERT INTO "entries" ("id", "trash", "heading", "entry", "created", "updated", "tags", "folder", "workspace", "favorite", "attachments", "type", "location", "subheading", "folder_id") VALUES ('230', '0', 'Welcome to Poznote', 'Poznote is a personal note-taking and documentation platform.
&nbsp;<br>&nbsp;<br>
Discover <a href="https://poznote.com/index.html#features" target="_blank" style="text-decoration: none;">all the features</a> included in Poznote.
&nbsp;<br>&nbsp;<br>
Click the <code>+</code> button to create your first note.
&nbsp;<br>&nbsp;<br>
Inside a note, type <code>/</code> to open the commands menu.<span style="font-size: 15px;">&nbsp;&nbsp;</span><div>

<p>I hope you will enjoy using Poznote! ✨</p>

<p><a href="https://ko-fi.com/timothepoznanski" target="_blank" style="text-decoration: none;">Tim</a></p></div>', '2026-01-24 00:50:32', '2026-01-24 00:52:39', '', 'Getting Started', 'Poznote', '0', NULL, 'note', NULL, NULL, '86');

DROP TABLE IF EXISTS "workspaces";
CREATE TABLE workspaces (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        created DATETIME DEFAULT CURRENT_TIMESTAMP
    );

INSERT INTO "workspaces" ("id", "name", "created") VALUES ('3', 'Poznote', '2026-01-23 23:24:46');

DROP TABLE IF EXISTS "settings";
CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );

INSERT INTO "settings" ("key", "value") VALUES ('emoji_icons_enabled', '1');
INSERT INTO "settings" ("key", "value") VALUES ('note_list_sort', 'updated_desc');
INSERT INTO "settings" ("key", "value") VALUES ('show_markdown_split_view_button', '1');
INSERT INTO "settings" ("key", "value") VALUES ('markdown_split_view_enabled', '1');
INSERT INTO "settings" ("key", "value") VALUES ('hide_folder_counts', '0');
INSERT INTO "settings" ("key", "value") VALUES ('show_note_created', '0');
INSERT INTO "settings" ("key", "value") VALUES ('show_note_subheading', '0');
INSERT INTO "settings" ("key", "value") VALUES ('hide_folder_actions', '0');
INSERT INTO "settings" ("key", "value") VALUES ('login_display_name', 'Demo');
INSERT INTO "settings" ("key", "value") VALUES ('language', 'en');
INSERT INTO "settings" ("key", "value") VALUES ('note_font_size', '15');
INSERT INTO "settings" ("key", "value") VALUES ('sidebar_font_size', '13');
INSERT INTO "settings" ("key", "value") VALUES ('center_note_content', '0');
INSERT INTO "settings" ("key", "value") VALUES ('last_opened_workspace', 'Poznote');

DROP TABLE IF EXISTS "shared_notes";
CREATE TABLE shared_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        note_id INTEGER NOT NULL,
        token TEXT UNIQUE NOT NULL,
        created DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires DATETIME, theme TEXT, indexable INTEGER DEFAULT 0, password TEXT,
        FOREIGN KEY(note_id) REFERENCES entries(id) ON DELETE CASCADE
    );


DROP TABLE IF EXISTS "folders";
CREATE TABLE "folders" (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    workspace TEXT DEFAULT "Poznote",
    parent_id INTEGER DEFAULT NULL,
    created DATETIME DEFAULT CURRENT_TIMESTAMP, icon TEXT, icon_color TEXT, kanban_enabled INTEGER DEFAULT 0,
    FOREIGN KEY (parent_id) REFERENCES "folders"(id) ON DELETE CASCADE
);

INSERT INTO "folders" ("id", "name", "workspace", "parent_id", "created", "icon", "icon_color", "kanban_enabled") VALUES ('86', 'Getting Started', 'Poznote', NULL, '2026-01-24 00:50:32', NULL, NULL, '0');

DROP TABLE IF EXISTS "shared_folders";
CREATE TABLE shared_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folder_id INTEGER NOT NULL,
        token TEXT UNIQUE NOT NULL,
        created DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires DATETIME,
        theme TEXT,
        indexable INTEGER DEFAULT 0,
        password TEXT,
        FOREIGN KEY(folder_id) REFERENCES folders(id) ON DELETE CASCADE
    );


